import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ModelType } from '../types';

interface LiveInterfaceProps {
  onClose: () => void;
}

// Audio helpers
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function createBlob(data: Float32Array) {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

const LiveInterface: React.FC<LiveInterfaceProps> = ({ onClose }) => {
  const [status, setStatus] = useState<'connecting' | 'connected' | 'error' | 'disconnected'>('connecting');
  const [logs, setLogs] = useState<string[]>([]);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Refs for cleanup
  const sessionRef = useRef<any>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const outputContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<number | null>(null);

  const addLog = (msg: string) => setLogs(prev => [...prev.slice(-4), msg]);

  useEffect(() => {
    let isMounted = true;

    const startSession = async () => {
      try {
        if (!process.env.API_KEY) throw new Error("No API Key");

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        // Setup Audio Contexts
        const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        inputContextRef.current = inputCtx;
        outputContextRef.current = outputCtx;

        const outputNode = outputCtx.createGain();
        outputNode.connect(outputCtx.destination);
        
        let nextStartTime = 0;

        // Get User Media (Audio + Video for Multimodal)
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
        streamRef.current = stream;
        
        if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
        }

        const sessionPromise = ai.live.connect({
          model: ModelType.LIVE_AUDIO,
          callbacks: {
            onopen: () => {
              if(!isMounted) return;
              setStatus('connected');
              addLog("Session Connected");

              // Audio Input Stream
              const source = inputCtx.createMediaStreamSource(stream);
              const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
              
              scriptProcessor.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                const pcmBlob = createBlob(inputData);
                sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
              };
              
              source.connect(scriptProcessor);
              scriptProcessor.connect(inputCtx.destination);
            },
            onmessage: async (msg: LiveServerMessage) => {
                // Audio Output
                const audioStr = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                if (audioStr) {
                    nextStartTime = Math.max(nextStartTime, outputCtx.currentTime);
                    
                    // Decode PCM
                    const bytes = decode(audioStr);
                    const dataInt16 = new Int16Array(bytes.buffer);
                    const float32 = new Float32Array(dataInt16.length);
                    for(let i=0; i<dataInt16.length; i++) {
                        float32[i] = dataInt16[i] / 32768.0;
                    }
                    
                    const buffer = outputCtx.createBuffer(1, float32.length, 24000);
                    buffer.getChannelData(0).set(float32);

                    const source = outputCtx.createBufferSource();
                    source.buffer = buffer;
                    source.connect(outputNode);
                    source.start(nextStartTime);
                    nextStartTime += buffer.duration;
                }
            },
            onclose: () => {
                if(isMounted) setStatus('disconnected');
            },
            onerror: (err) => {
                console.error(err);
                if(isMounted) setStatus('error');
            }
          },
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
            },
            systemInstruction: "You are Ziki, a helpful and cool AI assistant. Keep responses concise."
          }
        });

        sessionRef.current = sessionPromise;

        // Video Streaming Loop
        const canvas = canvasRef.current;
        if (canvas) {
            const ctx = canvas.getContext('2d');
            intervalRef.current = window.setInterval(async () => {
                if (!videoRef.current || !ctx) return;
                
                canvas.width = videoRef.current.videoWidth * 0.2; // Downscale for bandwidth
                canvas.height = videoRef.current.videoHeight * 0.2;
                
                ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
                
                const base64 = canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
                
                sessionPromise.then(session => {
                    session.sendRealtimeInput({
                        media: {
                            mimeType: 'image/jpeg',
                            data: base64
                        }
                    });
                });
            }, 1000); // 1 FPS for visual context
        }

      } catch (e) {
        console.error("Connection failed", e);
        setStatus('error');
      }
    };

    startSession();

    return () => {
      isMounted = false;
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
      if (inputContextRef.current) inputContextRef.current.close();
      if (outputContextRef.current) outputContextRef.current.close();
      if (intervalRef.current) clearInterval(intervalRef.current);
      // Close session if possible (method depends on SDK internals, usually auto-closes on disconnect)
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center text-white">
        <canvas ref={canvasRef} className="hidden" />
        
        <div className="relative w-full max-w-md aspect-[9/16] bg-gray-900 rounded-2xl overflow-hidden shadow-2xl border border-gray-800">
            {/* Camera View */}
            <video 
                ref={videoRef} 
                muted 
                playsInline 
                className="w-full h-full object-cover opacity-60"
            />

            {/* Overlay UI */}
            <div className="absolute inset-0 flex flex-col justify-between p-8">
                <div className="flex justify-between items-start">
                    <div className="bg-black/50 backdrop-blur px-3 py-1 rounded-full text-xs font-mono border border-white/10">
                        {status.toUpperCase()}
                    </div>
                    <button onClick={onClose} className="bg-red-500/80 hover:bg-red-600 p-3 rounded-full backdrop-blur transition">
                        <i className="fas fa-times"></i>
                    </button>
                </div>

                <div className="space-y-4">
                    <div className="flex justify-center">
                        <div className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500 ${status === 'connected' ? 'bg-blue-500/20 animate-pulse-slow border border-blue-400/50' : 'bg-gray-800'}`}>
                            <i className="fas fa-microphone text-4xl text-blue-400"></i>
                        </div>
                    </div>
                    
                    <div className="space-y-1">
                        {logs.map((log, i) => (
                            <div key={i} className="text-center text-xs text-white/50">{log}</div>
                        ))}
                    </div>
                    
                    <div className="text-center">
                        <h2 className="text-xl font-bold">Ziki Live</h2>
                        <p className="text-sm text-gray-400">Listening & Watching...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default LiveInterface;