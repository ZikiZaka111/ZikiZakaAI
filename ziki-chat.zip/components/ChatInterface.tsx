
import React, { useState, useRef, useEffect } from 'react';
import { Message, ChatSession, ModelType, Attachment, Folder, ModelDisplayNames, Emotion, Theme, Language, Persona } from '../types';
import { generateChatResponse, generateChatTitle } from '../services/geminiService';
import ZikiAvatar from './ZikiAvatar';

// --- Particle Background ---
const Particles = ({ theme, persona }: { theme: Theme, persona: Persona }) => {
    const [particles, setParticles] = useState<any[]>([]);
    useEffect(() => {
        const count = window.innerWidth <= 480 ? 12 : 20;
        const newParticles = Array.from({ length: count }).map((_, i) => ({
            id: i,
            size: Math.random() * 4 + 1.5,
            left: Math.random() * 100,
            delay: Math.random() * 18,
            duration: Math.random() * 22 + 16
        }));
        setParticles(newParticles);
    }, []);

    const getColor = () => {
        if (persona === 'zaka') return 'rgba(239, 68, 68, 0.15)'; // Red
        return theme === 'light' ? 'rgba(66, 133, 244, 0.2)' : 'rgba(138, 180, 248, 0.12)'; // Blue
    };

    return (
        <div className="particles" style={{ opacity: theme === 'light' ? 0.4 : 0.6 }}>
            {particles.map(p => (
                <div 
                    key={p.id}
                    className="particle"
                    style={{
                        width: p.size, height: p.size,
                        left: `${p.left}%`,
                        animationDelay: `${p.delay}s`,
                        animationDuration: `${p.duration}s`,
                        background: getColor()
                    }}
                />
            ))}
        </div>
    );
};

// --- Typing Indicator ---
const TypingIndicator = ({ theme, persona }: { theme: Theme, persona: Persona }) => (
    <div className={`flex gap-1.5 p-4 rounded-2xl w-fit items-center shadow-sm backdrop-blur-md border ${theme === 'light' ? 'bg-white border-gray-100' : 'bg-white/5 border-white/10'}`}>
        <div className={`w-1.5 h-1.5 rounded-full animate-typing ${persona === 'zaka' ? 'bg-red-500' : 'bg-blue-400'}`}></div>
        <div className={`w-1.5 h-1.5 rounded-full animate-typing delay-75 ${persona === 'zaka' ? 'bg-orange-500' : 'bg-purple-400'}`}></div>
        <div className={`w-1.5 h-1.5 rounded-full animate-typing delay-150 ${persona === 'zaka' ? 'bg-yellow-500' : 'bg-pink-400'}`}></div>
    </div>
);

// --- Sentiment Analysis ---
const analyzeSentiment = (text: string): Emotion => {
    if (!text) return 'neutral';
    const t = text.toLowerCase();
    if (t.includes('sorry') || t.includes('apologize') || t.includes('sad') || t.includes('unfortunately') || t.includes('lo siento') || t.includes('triste') || t.includes('perdón')) return 'sad';
    if (t.includes('!') || t.includes('great') || t.includes('happy') || t.includes('awesome') || t.includes('love') || t.includes('glad') || t.includes('genial') || t.includes('feliz') || t.includes('bien') || t.includes('me encanta')) return 'happy';
    if (t.includes('angry') || t.includes('hate') || t.includes('wrong') || t.includes('stop') || t.includes('error') || t.includes('fail') || t.includes('mal') || t.includes('odio') || t.includes('error') || t.includes('estúpido')) return 'angry';
    if (t.includes('wow') || t.includes('surprise') || t.includes('amazing') || t.includes('incredible') || t.includes('increíble') || t.includes('vaya')) return 'surprised';
    return 'neutral';
};

// --- Translations ---
const translations = {
    en: {
        newChat: "New Conversation",
        private: "PRIVATE",
        normal: "NORMAL",
        incognitoActive: "Incognito Mode Active",
        incognitoDesc: "Chats are not saved in history.\nData clears on reload.",
        general: "General",
        newFolder: "New Folder",
        folderName: "Folder Name",
        grounding: "Web Grounding",
        emotiveAvatar: "Emotive Avatar",
        globalSettings: "Global Settings",
        chatSettings: "Chat Settings",
        appearance: "Appearance",
        darkMode: "Dark Mode",
        lightMode: "Light Mode",
        language: "Language",
        intelligence: "Intelligence Level",
        fastStandard: "Fast & Standard",
        highReasoning: "High Reasoning",
        deepThinking: "Deep Thinking",
        moveToFolder: "Move to Folder",
        systemPrompt: "System Prompt (Custom Persona)",
        systemPromptPlaceholder: "e.g., You are a Python expert. Answer only in code.",
        done: "Done",
        hello: "Hello, I'm Ziki.",
        helloZaka: "Ugh. I'm Zaka.",
        intro: "I'm here to help with your tasks, thoughts, and ideas.",
        introZaka: "I don't really want to help, but fine. What do you want?",
        actions: ["Analyze this code", "Write a story", "Help me think", "Surprise me"],
        inputPlaceholder: "Message Ziki...",
        inputPlaceholderZaka: "Bother Zaka...",
        privatePlaceholder: "Private chat...",
        disclaimer: "AI can make mistakes. Verify important info.",
        errorConnect: "Connection failed.",
        thoughtProcess: "Thought Process",
        imageSent: "Image sent",
        analyzing: "Thinking...",
        source: "Source",
        modelFlash: "Fast & Standard",
        modelPro: "High Reasoning",
        modelThinking: "Deep Thinking",
        persona: "Persona",
        personaZiki: "Ziki (Obedient)",
        personaZaka: "Zaka (Demon)",
        settingsDescGlobal: "Configure language and look.",
        settingsDescChat: "Configure logic for this conversation.",
        rename: "Rename"
    },
    es: {
        newChat: "Nueva Conversación",
        private: "PRIVADO",
        normal: "NORMAL",
        incognitoActive: "Modo Incógnito Activo",
        incognitoDesc: "Los chats no se guardan en el historial.\nLos datos se borran al recargar.",
        general: "General",
        newFolder: "Nueva Carpeta",
        folderName: "Nombre de Carpeta",
        grounding: "Búsqueda Web",
        emotiveAvatar: "Avatar Emotivo",
        globalSettings: "Ajustes Globales",
        chatSettings: "Ajustes del Chat",
        appearance: "Apariencia",
        darkMode: "Modo Oscuro",
        lightMode: "Modo Claro",
        language: "Idioma",
        intelligence: "Nivel de Inteligencia",
        fastStandard: "Rápido y Estándar",
        highReasoning: "Razonamiento Alto",
        deepThinking: "Pensamiento Profundo",
        moveToFolder: "Mover a Carpeta",
        systemPrompt: "Prompt del Sistema (Persona)",
        systemPromptPlaceholder: "ej. Eres experto en Python. Responde solo con código.",
        done: "Listo",
        hello: "Hola, soy Ziki.",
        helloZaka: "Ugh. Soy Zaka.",
        intro: "Estoy aquí para ayudarte con tareas, ideas y pensamientos.",
        introZaka: "No quiero ayudar, pero vale. ¿Qué quieres?",
        actions: ["Analiza este código", "Escribe una historia", "Ayúdame a pensar", "Sorpréndeme"],
        inputPlaceholder: "Mensaje a Ziki...",
        inputPlaceholderZaka: "Molesta a Zaka...",
        privatePlaceholder: "Chat privado...",
        disclaimer: "IA puede cometer errores. Verifica la info importante.",
        errorConnect: "Fallo de conexión.",
        thoughtProcess: "Proceso de Pensamiento",
        imageSent: "Imagen enviada",
        analyzing: "Pensando...",
        source: "Fuente",
        modelFlash: "Rápido y Estándar",
        modelPro: "Razonamiento Alto",
        modelThinking: "Pensamiento Profundo",
        persona: "Personalidad",
        personaZiki: "Ziki (Obediente)",
        personaZaka: "Zaka (Demonio)",
        settingsDescGlobal: "Configura idioma y apariencia.",
        settingsDescChat: "Configura la lógica de esta conversación.",
        rename: "Renombrar"
    }
};

const ChatInterface: React.FC = () => {
    // --- State (Lazy Initialization for Persistence) ---
    const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('ziki_theme') as Theme) || 'dark');
    const [language, setLanguage] = useState<Language>(() => (localStorage.getItem('ziki_language') as Language) || 'en');
    const [persona, setPersona] = useState<Persona>(() => (localStorage.getItem('ziki_persona') as Persona) || 'ziki');
    
    // Chats & Folders: Lazy load to ensure we never overwrite with empty on first render
    const [chats, setChats] = useState<ChatSession[]>(() => {
        const saved = localStorage.getItem('ziki_chats');
        return saved ? JSON.parse(saved) : [];
    });
    
    const [folders, setFolders] = useState<Folder[]>(() => {
        const saved = localStorage.getItem('ziki_folders');
        const defaultFolders = [
            { id: 'general', name: 'General', isSystem: true, isOpen: true },
            { id: 'ziki', name: 'Ziki', isSystem: true, isOpen: true },
            { id: 'zaka', name: 'Zaka', isSystem: true, isOpen: true }
        ];
        if (saved) {
            const parsed: Folder[] = JSON.parse(saved);
            // Merge defaults if missing (e.g. upgrades)
            if (!parsed.some(f => f.id === 'ziki')) parsed.push({ id: 'ziki', name: 'Ziki', isSystem: true, isOpen: true });
            if (!parsed.some(f => f.id === 'zaka')) parsed.push({ id: 'zaka', name: 'Zaka', isSystem: true, isOpen: true });
            return parsed;
        }
        return defaultFolders;
    });
    
    const [currentChatId, setCurrentChatId] = useState<string | null>(null);
    
    // UI State
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSidebarOpen, setIsSidebarOpen] = useState(true); 
    const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
    const [isIncognito, setIsIncognito] = useState(false);
    
    // Modals
    const [settingsMode, setSettingsMode] = useState<'global' | 'chat' | null>(null);

    const [newFolderName, setNewFolderName] = useState('');
    const [isCreatingFolder, setIsCreatingFolder] = useState(false);

    // Chat Renaming
    const [editingChatId, setEditingChatId] = useState<string | null>(null);
    const [editTitleInput, setEditTitleInput] = useState('');
    
    // Emotive Mode
    const [emotiveMode, setEmotiveMode] = useState(true);
    const [currentEmotion, setCurrentEmotion] = useState<Emotion>('neutral');

    // Attachments
    const [attachments, setAttachments] = useState<Attachment[]>([]);
    
    // Default Global Settings
    const [globalModel, setGlobalModel] = useState<ModelType>(ModelType.FLASH);
    const [grounding, setGrounding] = useState(false);

    // Refs
    const bottomRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // Translation Helper
    const t = (key: keyof typeof translations['en']): string => {
        const val = translations[language][key];
        if (typeof val === 'string') return val;
        return key;
    };

    // --- Effects ---

    // AUTO-INIT: Ensure there is always a chat selected on mount
    useEffect(() => {
        if (!isIncognito && !currentChatId) {
            if (chats.length > 0) {
                // If chats exist, select the most recent one (index 0 usually)
                setCurrentChatId(chats[0].id);
            } else {
                // If no chats, create one immediately
                createNewChat();
            }
        }
    }, []); // Run once on mount

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 768) setIsSidebarOpen(false);
            else setIsSidebarOpen(true);
        };
        handleResize();
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    useEffect(() => {
        if (!isIncognito) localStorage.setItem('ziki_chats', JSON.stringify(chats));
    }, [chats, isIncognito]);

    useEffect(() => {
        if (!isIncognito) localStorage.setItem('ziki_folders', JSON.stringify(folders));
    }, [folders, isIncognito]);

    useEffect(() => {
        localStorage.setItem('ziki_theme', theme);
    }, [theme]);

    useEffect(() => {
        localStorage.setItem('ziki_language', language);
    }, [language]);

    useEffect(() => {
        localStorage.setItem('ziki_persona', persona);
    }, [persona]);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [chats, currentChatId, isLoading, isIncognito]);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
        }
    }, [input]);

    // --- Helper Logic ---

    const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

    const createNewChat = (folderId?: string, overrideModel?: ModelType) => {
        if (isIncognito) {
            setCurrentChatId('incognito');
            return;
        }

        let targetFolderId = folderId;
        if (!targetFolderId) {
            if (persona === 'zaka') targetFolderId = 'zaka';
            else targetFolderId = 'ziki';
        }

        const newChat: ChatSession = {
            id: Date.now().toString(),
            title: language === 'es' ? 'Nueva Conversación' : 'New Conversation',
            messages: [],
            lastUpdated: Date.now(),
            folderId: targetFolderId,
            modelPreference: overrideModel || globalModel
        };
        setChats(prev => [newChat, ...prev]);
        setCurrentChatId(newChat.id);
        setIsMobileSidebarOpen(false);
        setCurrentEmotion('neutral');
    };

    const handlePersonaChange = (newPersona: Persona) => {
        setPersona(newPersona);
        const targetFolder = newPersona === 'zaka' ? 'zaka' : 'ziki';
        
        const newChat: ChatSession = {
            id: Date.now().toString(),
            title: language === 'es' ? 'Nueva Conversación' : 'New Conversation',
            messages: [],
            lastUpdated: Date.now(),
            folderId: targetFolder,
            modelPreference: globalModel
        };
        setChats(prev => [newChat, ...prev]);
        setCurrentChatId(newChat.id);
        setCurrentEmotion('neutral');
    };

    const handleModelChange = (model: ModelType) => {
        const activeChat = chats.find(c => c.id === currentChatId);
        const currentFolder = activeChat?.folderId;
        createNewChat(currentFolder, model);
        setSettingsMode(null);
    };

    const deleteChat = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        
        // Filter out the deleted chat
        const newChats = chats.filter(c => c.id !== id);
        setChats(newChats);

        // If we deleted the current chat
        if (currentChatId === id) {
             if (newChats.length > 0) {
                 // Switch to the first available chat
                 setCurrentChatId(newChats[0].id);
             } else {
                 // If no chats left, create a new one immediately
                 // We use a timeout to let the state update first, 
                 // although with setState updater callback it's safer to just do it
                 // But we can't call createNewChat directly inside the setChats update easily.
                 // So we do it here:
                 
                 const targetFolder = persona === 'zaka' ? 'zaka' : 'ziki';
                 const newChat: ChatSession = {
                    id: Date.now().toString(),
                    title: language === 'es' ? 'Nueva Conversación' : 'New Conversation',
                    messages: [],
                    lastUpdated: Date.now(),
                    folderId: targetFolder,
                    modelPreference: globalModel
                };
                setChats([newChat]);
                setCurrentChatId(newChat.id);
             }
        }
    };

    const startEditingChat = (e: React.MouseEvent, chat: ChatSession) => {
        e.stopPropagation();
        setEditingChatId(chat.id);
        setEditTitleInput(chat.title);
    };

    const handleRenameChat = (chatId: string) => {
        if (editTitleInput.trim()) {
            setChats(prev => prev.map(c => c.id === chatId ? { ...c, title: editTitleInput.trim() } : c));
        }
        setEditingChatId(null);
    };

    const createFolder = () => {
        if (!newFolderName.trim()) return;
        const newFolder: Folder = {
            id: Date.now().toString(),
            name: newFolderName,
            isOpen: true
        };
        setFolders(prev => [...prev, newFolder]);
        setNewFolderName('');
        setIsCreatingFolder(false);
    };

    const toggleFolder = (folderId: string) => {
        setFolders(prev => prev.map(f => f.id === folderId ? { ...f, isOpen: !f.isOpen } : f));
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onloadend = () => {
            setAttachments(prev => [...prev, {
                mimeType: file.type,
                data: (reader.result as string).split(',')[1],
                name: file.name
            }]);
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    };

    const toggleIncognito = () => {
        setIsIncognito(prev => !prev);
        // Toggle logic
        if (!isIncognito) {
            // Turning ON Incognito
            setCurrentChatId(null);
        } else {
            // Turning OFF Incognito
            if (chats.length > 0) {
                setCurrentChatId(chats[0].id);
            } else {
                createNewChat();
            }
        }
        
        setIsMobileSidebarOpen(false);
        setCurrentEmotion('neutral');
        setIncognitoMessages([]);
    };

    const updateChatSettings = (updates: Partial<ChatSession>) => {
        if (!currentChatId || isIncognito) return;
        setChats(prev => prev.map(c => c.id === currentChatId ? { ...c, ...updates } : c));
    };

    // --- Messaging Logic ---
    const [incognitoMessages, setIncognitoMessages] = useState<Message[]>([]);

    const handleSend = async () => {
        if ((!input.trim() && attachments.length === 0) || isLoading) return;

        let activeChatId = currentChatId;
        
        // Safety check: if somehow no chat ID in normal mode, create one
        if (!activeChatId && !isIncognito) {
            const targetFolder = persona === 'zaka' ? 'zaka' : 'ziki';
            const newChat: ChatSession = {
                id: Date.now().toString(),
                title: language === 'es' ? 'Nueva Conversación' : 'New Conversation',
                messages: [],
                lastUpdated: Date.now(),
                folderId: targetFolder,
                modelPreference: globalModel
            };
            setChats(prev => [newChat, ...prev]);
            activeChatId = newChat.id;
            setCurrentChatId(activeChatId);
        }

        const userMsg: Message = {
            id: Date.now().toString(),
            role: 'user',
            text: input,
            attachments: [...attachments],
            timestamp: Date.now()
        };

        if (isIncognito) {
            setIncognitoMessages(prev => [...prev, userMsg]);
        } else {
            setChats(prev => prev.map(c => 
                c.id === activeChatId 
                    ? { ...c, messages: [...c.messages, userMsg], lastUpdated: Date.now() }
                    : c
            ));
        }

        const inputTextSnapshot = input;
        setInput('');
        setAttachments([]);
        if (textareaRef.current) textareaRef.current.style.height = 'auto';
        
        setIsLoading(true);
        setCurrentEmotion('thinking'); 

        const activeChat = chats.find(c => c.id === activeChatId);
        const modelToUse = activeChat?.modelPreference || globalModel;
        const systemInstruction = activeChat?.systemInstruction;

        try {
            let historyMessages = isIncognito ? incognitoMessages : (activeChat?.messages || []);
            const history = historyMessages.map(m => ({ 
                role: m.role, 
                parts: [{ text: m.text || (m.attachments ? t('imageSent') : "") }] 
            }));

            const response = await generateChatResponse(
                history,
                userMsg.text || '',
                userMsg.attachments || [],
                modelToUse,
                grounding,
                systemInstruction,
                persona,
                language
            );

            const newEmotion = analyzeSentiment(response.text);
            setCurrentEmotion(newEmotion);

            const botMsg: Message = {
                id: (Date.now() + 1).toString(),
                role: 'model',
                text: response.text,
                thoughtProcess: response.thoughtProcess,
                groundingUrls: response.groundingUrls,
                timestamp: Date.now()
            };

            if (isIncognito) {
                setIncognitoMessages(prev => [...prev, botMsg]);
            } else {
                setChats(prev => prev.map(c => {
                    if (c.id === activeChatId) {
                        return {
                            ...c,
                            messages: [...c.messages, botMsg],
                            lastUpdated: Date.now()
                        };
                    }
                    return c;
                }));

                // Auto-title if it's the first exchange
                if (activeChatId && (!activeChat || activeChat.messages.length === 0)) {
                    generateChatTitle(inputTextSnapshot, response.text, language).then(generatedTitle => {
                         setChats(prev => prev.map(c => c.id === activeChatId ? { ...c, title: generatedTitle } : c));
                    });
                }
            }
        } catch (e) {
            console.error(e);
            setCurrentEmotion('angry'); 
             const errorMsg: Message = {
                id: (Date.now() + 1).toString(),
                role: 'model',
                text: t('errorConnect'),
                timestamp: Date.now()
            };
            if(isIncognito) setIncognitoMessages(prev => [...prev, errorMsg]);
            else setChats(prev => prev.map(c => c.id === activeChatId ? {...c, messages: [...c.messages, errorMsg]} : c));
        } finally {
            setIsLoading(false);
            setTimeout(() => {
                setCurrentEmotion(prev => prev === 'thinking' ? 'neutral' : prev);
            }, 6000);
        }
    };

    // --- Render Helpers ---
    const activeChat = chats.find(c => c.id === currentChatId);
    const messagesToRender = isIncognito ? incognitoMessages : (activeChat?.messages || []);
    const currentModel = isIncognito ? globalModel : (activeChat?.modelPreference || globalModel);
    const currentTitle = isIncognito ? t('incognitoActive') : (activeChat?.title || "Ziki");

    // Theme Variables
    const isDark = theme === 'dark' || isIncognito || persona === 'zaka';
    const bgMain = isDark ? (persona === 'zaka' ? 'bg-[#1a0505]' : 'bg-[#0f0f12]') : 'bg-gray-50';
    const bgSidebar = isDark ? (persona === 'zaka' ? 'bg-[#200505]/95 border-red-900/30' : 'bg-[#141419]/95 border-white/5') : 'bg-white/95 border-gray-200';
    const textMain = isDark ? (persona === 'zaka' ? 'text-red-100' : 'text-gray-100') : 'text-gray-900';
    const textMuted = isDark ? (persona === 'zaka' ? 'text-red-300/50' : 'text-gray-400') : 'text-gray-500';
    const hoverBg = isDark ? 'hover:bg-white/5' : 'hover:bg-gray-100';

    const getFolderName = (folder: Folder) => {
        if (folder.id === 'general') return t('general');
        if (folder.id === 'ziki') return 'Ziki';
        if (folder.id === 'zaka') return 'Zaka';
        return folder.name;
    };

    return (
        <div className={`flex h-screen relative overflow-hidden font-sans transition-colors duration-300 ${bgMain} ${textMain}`}>
            <Particles theme={theme} persona={persona} />

            {/* --- Overlay for Mobile --- */}
            {(isMobileSidebarOpen) && (
                <div 
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 md:hidden transition-all duration-300"
                    onClick={() => setIsMobileSidebarOpen(false)}
                />
            )}

            {/* --- Sidebar (Left) --- */}
            <aside className={`
                fixed md:relative z-40 h-full flex flex-col transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] pt-[env(safe-area-inset-top)] border-r backdrop-blur-2xl
                ${isIncognito ? 'bg-black/95 border-red-900/30' : bgSidebar}
                ${isMobileSidebarOpen ? 'translate-x-0 w-[280px]' : '-translate-x-full md:translate-x-0'}
                ${isSidebarOpen ? 'md:w-[280px] md:opacity-100' : 'md:w-0 md:opacity-0 md:overflow-hidden md:border-none'}
            `}>
                <div className="p-5 flex flex-col gap-6">
                    {/* Logo Area */}
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-lg transition-colors ${
                                persona === 'zaka' 
                                ? 'bg-gradient-to-tr from-red-600 to-orange-600 shadow-red-500/20' 
                                : (isIncognito ? 'bg-red-900/50 shadow-red-900/20' : 'bg-gradient-to-tr from-blue-600 to-purple-600 shadow-blue-500/20')
                            }`}>
                                <span className="font-bold text-white text-lg">Z</span>
                            </div>
                            <h2 className={`font-bold text-xl tracking-tight ${isIncognito ? 'text-gray-200' : (isDark ? 'text-white' : 'text-gray-800')}`}>
                                {persona === 'zaka' ? 'Zaka' : 'Ziki'}
                            </h2>
                        </div>
                        <button 
                            onClick={toggleIncognito} 
                            className={`text-[10px] font-bold tracking-wider px-2.5 py-1 rounded-full border transition-all ${isIncognito ? 'bg-red-500/10 border-red-500/50 text-red-400 shadow-[0_0_10px_rgba(239,68,68,0.2)]' : (isDark ? 'bg-white/5 border-white/10 text-gray-400 hover:text-white' : 'bg-gray-100 border-gray-200 text-gray-500 hover:text-gray-900')}`}
                        >
                            {isIncognito ? t('private') : t('normal')}
                        </button>
                    </div>

                    {!isIncognito && (
                        <button 
                            onClick={() => createNewChat()}
                            className={`w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 border transition-all duration-200 group
                                ${isDark 
                                    ? 'bg-white/10 hover:bg-white/15 text-white border-white/5' 
                                    : 'bg-white hover:bg-gray-50 text-gray-800 border-gray-200 shadow-sm'}
                            `}
                        >
                            <i className={`fas fa-plus ${persona === 'zaka' ? 'text-red-500' : 'text-blue-500'} group-hover:scale-110 transition-transform`}></i> {t('newChat')}
                        </button>
                    )}
                </div>

                <div className="flex-1 overflow-y-auto px-3 space-y-1 no-scrollbar pb-4">
                    {isIncognito ? (
                         <div className="flex flex-col items-center justify-center h-64 text-center px-4 animate-fade-in">
                            <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                                <i className="fas fa-user-secret text-3xl text-gray-500"></i>
                            </div>
                            <p className="text-gray-300 font-medium">{t('incognitoActive')}</p>
                            <p className="text-xs text-gray-500 mt-2 leading-relaxed whitespace-pre-wrap">{t('incognitoDesc')}</p>
                        </div>
                    ) : (
                        <>
                            {folders.map(folder => (
                                <div key={folder.id} className="mb-2">
                                    <div 
                                        onClick={() => toggleFolder(folder.id)}
                                        className={`flex items-center justify-between px-3 py-2 text-[11px] font-bold uppercase tracking-wider cursor-pointer transition group select-none ${textMuted} hover:text-blue-500`}
                                    >
                                        <span className="flex items-center gap-2">
                                            <i className={`fas fa-chevron-right transition-transform duration-200 text-[9px] ${folder.isOpen ? 'rotate-90' : ''}`}></i>
                                            {getFolderName(folder)}
                                        </span>
                                        <span className="opacity-0 group-hover:opacity-100 flex items-center gap-3 transition-opacity">
                                            {!folder.isSystem && (
                                                <i className="fas fa-trash hover:text-red-400 transition" onClick={(e) => {
                                                    e.stopPropagation();
                                                    setFolders(prev => prev.filter(f => f.id !== folder.id));
                                                }}></i>
                                            )}
                                            <i className="fas fa-plus hover:text-blue-400 transition" onClick={(e) => {
                                                e.stopPropagation();
                                                createNewChat(folder.id);
                                            }} title="New chat in folder"></i>
                                        </span>
                                    </div>
                                    
                                    {folder.isOpen && (
                                        <div className={`space-y-0.5 ml-2 pl-2 border-l ${isDark ? 'border-white/5' : 'border-gray-200'}`}>
                                            {chats.filter(c => (c.folderId || 'general') === folder.id).map(chat => (
                                                <div 
                                                    key={chat.id}
                                                    onClick={() => { setCurrentChatId(chat.id); setIsMobileSidebarOpen(false); }}
                                                    className={`
                                                        group relative px-3 py-2.5 rounded-lg cursor-pointer transition-all duration-200 flex items-center justify-between
                                                        ${chat.id === currentChatId 
                                                            ? (persona === 'zaka' ? 'bg-red-900/20 text-red-500 border-l-2 border-red-500' : 'bg-blue-500/10 text-blue-500 border-l-2 border-blue-500')
                                                            : `${textMuted} ${hoverBg} ${isDark ? 'hover:text-gray-200' : 'hover:text-gray-900'} border-l-2 border-transparent`}
                                                    `}
                                                >
                                                    {editingChatId === chat.id ? (
                                                        <div className="flex items-center gap-1 w-full" onClick={e => e.stopPropagation()}>
                                                            <input 
                                                                autoFocus
                                                                value={editTitleInput}
                                                                onChange={(e) => setEditTitleInput(e.target.value)}
                                                                onKeyDown={(e) => {
                                                                    if(e.key === 'Enter') handleRenameChat(chat.id);
                                                                    if(e.key === 'Escape') setEditingChatId(null);
                                                                }}
                                                                onBlur={() => handleRenameChat(chat.id)}
                                                                className={`w-full bg-transparent text-sm outline-none border-b border-blue-500 ${isDark ? 'text-white' : 'text-black'}`}
                                                            />
                                                        </div>
                                                    ) : (
                                                        <div className="truncate text-sm pr-12 font-medium w-full relative">
                                                            {chat.title}
                                                        </div>
                                                    )}
                                                    
                                                    {/* Actions: Rename & Delete */}
                                                    <div className={`absolute right-2 opacity-0 group-hover:opacity-100 transition-all flex gap-1 ${isDark ? 'bg-[#141419]' : 'bg-white'}`}>
                                                        <button 
                                                            onClick={(e) => startEditingChat(e, chat)}
                                                            className="p-1 hover:text-blue-400"
                                                            title={t('rename')}
                                                        >
                                                            <i className="fas fa-pen text-xs"></i>
                                                        </button>
                                                        <button 
                                                            onClick={(e) => deleteChat(e, chat.id)}
                                                            className="p-1 hover:text-red-400"
                                                        >
                                                            <i className="fas fa-times text-xs"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            ))}
                             {/* Create Folder */}
                             <div className="mt-4 px-2">
                                {isCreatingFolder ? (
                                    <div className={`flex gap-2 items-center animate-fade-in p-1.5 rounded-lg border ${isDark ? 'bg-white/5 border-white/10' : 'bg-white border-gray-200 shadow-sm'}`}>
                                        <input 
                                            autoFocus
                                            value={newFolderName}
                                            onChange={(e) => setNewFolderName(e.target.value)}
                                            placeholder={t('folderName')}
                                            className={`w-full bg-transparent text-sm outline-none px-1 ${textMain}`}
                                            onKeyDown={(e) => e.key === 'Enter' && createFolder()}
                                        />
                                        <button onClick={createFolder} className="text-green-500 hover:bg-green-500/10 p-1 rounded transition"><i className="fas fa-check"></i></button>
                                        <button onClick={() => setIsCreatingFolder(false)} className="text-red-500 hover:bg-red-500/10 p-1 rounded transition"><i className="fas fa-times"></i></button>
                                    </div>
                                ) : (
                                    <button 
                                        onClick={() => setIsCreatingFolder(true)}
                                        className={`w-full py-2.5 border border-dashed rounded-lg text-xs transition-all flex items-center justify-center gap-2 ${isDark ? 'border-white/10 text-gray-500 hover:text-white hover:border-white/30 hover:bg-white/5' : 'border-gray-300 text-gray-500 hover:text-gray-900 hover:border-gray-400 hover:bg-gray-50'}`}
                                    >
                                        <i className="fas fa-folder-plus"></i> {t('newFolder')}
                                    </button>
                                )}
                            </div>
                        </>
                    )}
                </div>

                {/* Footer Controls */}
                <div className={`p-4 border-t space-y-2 ${isDark ? (persona === 'zaka' ? 'border-white/5 bg-red-950/20' : 'border-white/5 bg-black/20') : 'border-gray-200 bg-gray-50'}`}>
                     <button 
                        onClick={() => setGrounding(!grounding)}
                        className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold border transition-all ${
                            grounding 
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500' 
                            : `${isDark ? 'bg-white/5 border-transparent text-gray-400 hover:bg-white/10' : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-100'}`
                        }`}
                    >
                        <span><i className="fas fa-globe mr-2"></i>{t('grounding')}</span>
                        <div className={`w-8 h-4 rounded-full relative transition-colors ${grounding ? 'bg-emerald-500' : 'bg-gray-400'}`}>
                            <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all`} style={{ left: grounding ? 'calc(100% - 14px)' : '2px'}}></div>
                        </div>
                    </button>
                    
                    <button 
                        onClick={() => setEmotiveMode(!emotiveMode)}
                        className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold border transition-all ${
                            emotiveMode 
                            ? (persona === 'zaka' ? 'bg-orange-500/10 border-orange-500/30 text-orange-500' : 'bg-purple-500/10 border-purple-500/30 text-purple-500') 
                            : `${isDark ? 'bg-white/5 border-transparent text-gray-400 hover:bg-white/10' : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-100'}`
                        }`}
                    >
                         <span><i className="fas fa-smile mr-2"></i>{t('emotiveAvatar')}</span>
                         <div className={`w-8 h-4 rounded-full relative transition-colors ${emotiveMode ? (persona === 'zaka' ? 'bg-orange-500' : 'bg-purple-500') : 'bg-gray-400'}`}>
                            <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all`} style={{ left: emotiveMode ? 'calc(100% - 14px)' : '2px'}}></div>
                        </div>
                    </button>

                    <button 
                        onClick={() => setSettingsMode('global')}
                        className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold border transition-all ${isDark ? 'bg-white/5 border-transparent text-gray-400 hover:bg-white/10' : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-100'}`}
                    >
                         <span><i className="fas fa-cog mr-2"></i>{t('globalSettings')}</span>
                    </button>
                </div>
            </aside>

            {/* --- Main Area --- */}
            <main className="flex-1 flex flex-col relative min-w-0 h-screen">
                
                {/* Header */}
                <header className={`flex items-center justify-between px-4 md:px-6 py-3 border-b z-10 sticky top-0 backdrop-blur-xl w-full ${isDark ? 'border-white/5 bg-[#0f0f12]/80' : 'border-gray-200 bg-white/80'}`}>
                    <div className="flex items-center gap-4">
                        <button onClick={() => setIsMobileSidebarOpen(true)} className={`md:hidden p-2 -ml-2 rounded-lg transition ${isDark ? 'text-white hover:bg-white/10' : 'text-gray-800 hover:bg-gray-100'}`}>
                            <i className="fas fa-bars"></i>
                        </button>
                        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className={`hidden md:flex transition-colors ${textMuted} hover:text-blue-500`}>
                            <i className="fas fa-columns text-lg"></i>
                        </button>
                        
                        <div className="flex flex-col">
                            <h1 className={`font-bold text-lg tracking-tight flex items-center gap-3 truncate max-w-[200px] md:max-w-md ${isDark ? 'text-white' : 'text-gray-900'}`}>
                                {currentTitle}
                            </h1>
                            {!isIncognito && activeChat && (
                                <div className="flex items-center gap-2 mt-0.5">
                                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wide ${persona === 'zaka' ? 'text-red-500 bg-red-500/10 border-red-500/20' : 'text-blue-500 bg-blue-500/10 border-blue-500/20'}`}>
                                        {ModelDisplayNames[activeChat.modelPreference || globalModel]}
                                    </span>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        {/* Only show small avatar in header on MOBILE (hidden lg) */}
                        {emotiveMode && (
                            <div className="block lg:hidden scale-75 origin-right">
                                <ZikiAvatar emotion={currentEmotion} size="sm" persona={persona} />
                            </div>
                        )}
                        {!isIncognito && currentChatId && (
                            <button 
                                onClick={() => setSettingsMode('chat')}
                                className={`w-8 h-8 flex items-center justify-center rounded-full transition-all border ${isDark ? 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/15 border-white/5' : 'bg-gray-100 text-gray-600 hover:text-gray-900 hover:bg-gray-200 border-gray-200'}`}
                                title={t('chatSettings')}
                            >
                                <i className="fas fa-sliders-h text-sm"></i>
                            </button>
                        )}
                    </div>
                </header>

                {/* Content Wrapper (Chat + Right Sidebar) */}
                <div className="flex-1 flex overflow-hidden relative">
                    
                    {/* Chat Column */}
                    <div className="flex-1 flex flex-col h-full relative min-w-0">
                         {/* Messages */}
                        <div className="flex-1 overflow-y-auto w-full px-4 md:px-12 pt-6 pb-6 space-y-8 scroll-smooth custom-scrollbar">
                            {messagesToRender.length === 0 && (
                                <div className="flex flex-col items-center justify-center h-full select-none pb-20 animate-fade-in w-full">
                                    {emotiveMode && (
                                        // Show avatar here in empty state only if NOT visible in sidebar (mobile)
                                        <div className="mb-6 scale-75 md:scale-100 lg:hidden">
                                            <ZikiAvatar emotion={currentEmotion} size="lg" persona={persona} />
                                        </div>
                                    )}
                                    {!emotiveMode && (
                                        <div className={`w-20 h-20 rounded-full mb-6 flex items-center justify-center border border-white/5 shadow-lg ${persona === 'zaka' ? 'bg-gradient-to-tr from-red-500/20 to-orange-500/20' : 'bg-gradient-to-tr from-blue-500/20 to-purple-500/20'}`}>
                                            <span className={`text-3xl font-bold bg-clip-text text-transparent ${persona === 'zaka' ? 'bg-gradient-to-tr from-red-400 to-orange-400' : 'bg-gradient-to-tr from-blue-400 to-purple-400'}`}>Z</span>
                                        </div>
                                    )}
                                    <h2 className={`text-2xl font-bold mb-2 tracking-tight ${isDark ? 'text-white' : 'text-gray-800'}`}>{persona === 'zaka' ? t('helloZaka') : t('hello')}</h2>
                                    <p className={`max-w-sm text-center text-sm leading-relaxed ${textMuted}`}>
                                        {persona === 'zaka' ? t('introZaka') : t('intro')}
                                    </p>
                                    
                                    {/* Quick Actions */}
                                    <div className="grid grid-cols-2 gap-3 mt-8 max-w-lg w-full px-4">
                                        {translations[language].actions.map((action, i) => (
                                            <button 
                                                key={i}
                                                onClick={() => { setInput(action); }}
                                                className={`p-3 rounded-xl text-xs transition-all text-left border ${isDark ? 'bg-white/5 hover:bg-white/10 border-white/5 text-gray-300' : 'bg-white hover:bg-gray-50 border-gray-200 text-gray-600 shadow-sm'}`}
                                            >
                                                {action}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {messagesToRender.map((msg) => (
                                <div key={msg.id} className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in group`}>
                                    {/* Small avatar next to message bubbles on MOBILE only */}
                                    {msg.role === 'model' && emotiveMode && (
                                        <div className="mr-3 mt-1 hidden md:block lg:hidden opacity-0 group-hover:opacity-100 transition-opacity scale-90 origin-top-left">
                                            <ZikiAvatar emotion={currentEmotion} size="xs" persona={persona} />
                                        </div>
                                    )}
                                    <div className={`
                                        max-w-[90%] md:max-w-[80%] rounded-2xl p-4 md:p-5 shadow-sm transition-all
                                        ${msg.role === 'user' 
                                            ? 'bg-[#2d3748] text-white rounded-br-sm shadow-md' 
                                            : `${isDark ? 'bg-white/5 text-gray-200 border border-white/10' : 'bg-white text-gray-800 border border-gray-200'} rounded-bl-sm`}
                                    `}>
                                        {msg.attachments?.map((att, i) => (
                                            <div key={i} className="mb-4 rounded-xl overflow-hidden border border-white/10 shadow-lg bg-black/50">
                                                <img src={`data:${att.mimeType};base64,${att.data}`} className="max-w-full max-h-96 object-contain" alt="attachment" />
                                            </div>
                                        ))}

                                        {/* Thought Process Block */}
                                        {msg.thoughtProcess && (
                                            <details className="mb-4 group/details">
                                                <summary className={`cursor-pointer list-none text-xs font-bold uppercase tracking-wider flex items-center gap-2 select-none opacity-80 hover:opacity-100 transition-opacity ${persona === 'zaka' ? 'text-orange-400' : 'text-purple-400'}`}>
                                                    <i className="fas fa-brain"></i>
                                                    <span>{t('thoughtProcess')}</span>
                                                    <i className="fas fa-chevron-down transition-transform group-open/details:rotate-180"></i>
                                                </summary>
                                                <div className={`mt-2 p-3 bg-black/30 rounded-lg border text-sm font-mono leading-relaxed whitespace-pre-wrap ${persona === 'zaka' ? 'border-orange-500/20 text-orange-200/80' : 'border-purple-500/20 text-purple-200/80'}`}>
                                                    {msg.thoughtProcess}
                                                </div>
                                            </details>
                                        )}
                                        
                                        <div className="whitespace-pre-wrap leading-7 text-[15px] font-light tracking-wide">
                                            {msg.text}
                                        </div>

                                        {msg.groundingUrls && msg.groundingUrls.length > 0 && (
                                            <div className={`mt-4 pt-3 border-t flex flex-wrap gap-2 ${isDark ? 'border-white/10' : 'border-gray-100'}`}>
                                                {msg.groundingUrls.map((url, i) => (
                                                    <a 
                                                        key={i} href={url.uri} target="_blank" rel="noreferrer"
                                                        className={`inline-flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-wider px-3 py-1.5 rounded-full transition border ${isDark ? 'bg-black/30 hover:bg-emerald-900/30 text-emerald-400 border-transparent' : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100 border-emerald-100'}`}
                                                    >
                                                        <i className="fas fa-link text-[9px]"></i> {url.title}
                                                    </a>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                            {isLoading && (
                                <div className="flex justify-start w-full animate-fade-in pl-2 md:pl-12 lg:pl-0">
                                    <TypingIndicator theme={theme} persona={persona} />
                                </div>
                            )}
                            <div ref={bottomRef} className="h-4" />
                        </div>

                        {/* Input Area */}
                        <div className={`p-4 md:p-6 backdrop-blur-xl border-t relative z-20 w-full ${isDark ? 'border-white/5' : 'border-gray-200'}`}>
                            <div className="max-w-4xl mx-auto flex flex-col gap-3 relative">
                                {attachments.length > 0 && (
                                    <div className="flex gap-3 overflow-x-auto pb-2 absolute bottom-full mb-2 left-0 w-full px-2">
                                        {attachments.map((att, i) => (
                                            <div key={i} className="relative group shrink-0 animate-fade-in">
                                                <div className="w-16 h-16 rounded-xl bg-gray-800 border border-white/10 overflow-hidden shadow-2xl">
                                                    <img src={`data:${att.mimeType};base64,${att.data}`} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition" alt="preview" />
                                                </div>
                                                <button 
                                                    onClick={() => setAttachments(prev => prev.filter((_, idx) => idx !== i))}
                                                    className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 rounded-full text-white text-[10px] flex items-center justify-center shadow-lg transform hover:scale-110 transition"
                                                >
                                                    <i className="fas fa-times"></i>
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                <div className={`
                                    flex gap-2 items-end p-2 rounded-[26px] border transition-all duration-300 shadow-lg
                                    ${isIncognito 
                                        ? 'bg-gray-900 border-red-900/20' 
                                        : (isDark ? 'bg-[#1e1e24] border-white/10 focus-within:border-blue-500/30' : 'bg-white border-gray-300 focus-within:border-blue-400 focus-within:shadow-blue-100')}
                                `}>
                                    <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" accept="image/*" />
                                    <button 
                                        onClick={() => fileInputRef.current?.click()}
                                        className="w-10 h-10 flex items-center justify-center rounded-full text-gray-400 hover:text-blue-500 hover:bg-blue-500/10 transition-all shrink-0 ml-1 mb-0.5"
                                        title="Add Image"
                                    >
                                        <i className="fas fa-paperclip text-lg"></i>
                                    </button>
                                    
                                    <div className="flex-1 relative py-2.5">
                                        <textarea
                                            ref={textareaRef}
                                            value={input}
                                            onChange={(e) => setInput(e.target.value)}
                                            onKeyDown={(e) => {
                                                if (e.key === 'Enter' && !e.shiftKey) {
                                                    e.preventDefault();
                                                    handleSend();
                                                }
                                            }}
                                            placeholder={isIncognito ? t('privatePlaceholder') : (persona === 'zaka' ? t('inputPlaceholderZaka') : t('inputPlaceholder'))}
                                            rows={1}
                                            className={`w-full bg-transparent px-2 outline-none resize-none max-h-32 text-[15px] scrollbar-hide ${isDark ? 'text-white placeholder-gray-500' : 'text-gray-900 placeholder-gray-400'}`}
                                            style={{ minHeight: '24px' }}
                                        />
                                    </div>

                                    <button 
                                        onClick={handleSend}
                                        disabled={(!input.trim() && attachments.length === 0) || isLoading}
                                        className={`
                                            w-10 h-10 flex items-center justify-center rounded-full shrink-0 transition-all mb-0.5 mr-1
                                            ${(!input.trim() && attachments.length === 0) || isLoading
                                                ? 'bg-gray-200 text-gray-400 cursor-not-allowed dark:bg-white/5 dark:text-gray-600' 
                                                : `${persona === 'zaka' ? 'bg-red-600 hover:bg-red-500 shadow-red-600/30' : 'bg-blue-600 hover:bg-blue-500 shadow-blue-600/30'} text-white shadow-lg transform hover:scale-105 active:scale-95`}
                                        `}
                                    >
                                        <i className={`fas ${isLoading ? 'fa-circle-notch fa-spin' : 'fa-arrow-up'}`}></i>
                                    </button>
                                </div>
                                <div className="text-center">
                                    <span className="text-[10px] text-gray-500 font-medium">{t('disclaimer')}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* --- Right Sidebar (Desktop Avatar) --- */}
                    {emotiveMode && (
                        <div className={`hidden lg:flex w-[200px] xl:w-[280px] flex-col items-center justify-center border-l backdrop-blur-sm z-20 relative transition-colors duration-500 ${
                            isDark 
                                ? (persona === 'zaka' ? 'border-red-900/30 bg-gradient-to-l from-red-950/20 to-transparent' : 'border-white/5 bg-gradient-to-l from-blue-900/10 to-transparent') 
                                : 'border-gray-200 bg-gray-50/50'
                        }`}>
                            <div className="flex flex-col items-center gap-8">
                                <div className="scale-125 xl:scale-150 transform transition-transform duration-500 hover:scale-[1.6]">
                                    <ZikiAvatar emotion={currentEmotion} size="lg" persona={persona} />
                                </div>
                                
                                <div className={`text-center space-y-1 animate-fade-in ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                                    <div className={`text-xs font-bold uppercase tracking-[0.2em] ${persona === 'zaka' ? 'text-red-500' : 'text-blue-500'}`}>
                                        {persona === 'zaka' ? 'Zaka' : 'Ziki'}
                                    </div>
                                    <div className="text-sm font-medium opacity-70 capitalize">
                                        {currentEmotion}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* --- Settings Modal --- */}
                {(settingsMode !== null) && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in p-4" onClick={() => setSettingsMode(null)}>
                        <div className={`border rounded-2xl p-6 w-full max-w-md shadow-2xl relative overflow-hidden transform scale-100 transition-all ${isDark ? 'bg-[#1e1e24] border-white/10' : 'bg-white border-gray-200'}`} onClick={e => e.stopPropagation()}>
                            <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${persona === 'zaka' ? 'from-red-600 via-orange-600 to-yellow-600' : 'from-blue-500 via-purple-500 to-pink-500'}`}></div>
                            <button onClick={() => setSettingsMode(null)} className={`absolute top-4 right-4 transition rounded-full w-8 h-8 flex items-center justify-center ${isDark ? 'text-gray-500 hover:text-white bg-white/5 hover:bg-white/10' : 'text-gray-500 hover:text-gray-900 bg-gray-100 hover:bg-gray-200'}`}>
                                <i className="fas fa-times"></i>
                            </button>
                            
                            <h2 className={`text-xl font-bold mb-1 ${isDark ? 'text-white' : 'text-gray-900'}`}>{settingsMode === 'global' ? t('globalSettings') : t('chatSettings')}</h2>
                            <p className={`text-xs mb-6 ${textMuted}`}>{settingsMode === 'global' ? t('settingsDescGlobal') : t('settingsDescChat')}</p>

                            <div className="space-y-6">
                                
                                {settingsMode === 'global' && (
                                    <>
                                        {/* Language */}
                                        <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-white/5">
                                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">{t('language')}</label>
                                            <div className="flex gap-2">
                                                <button 
                                                    onClick={() => setLanguage('en')}
                                                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${language === 'en' ? 'bg-blue-500 text-white border-blue-500' : `${isDark ? 'bg-white/5 text-gray-400 border-white/10' : 'bg-gray-100 text-gray-600 border-gray-200'}`}`}
                                                >
                                                    English
                                                </button>
                                                <button 
                                                    onClick={() => setLanguage('es')}
                                                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${language === 'es' ? 'bg-blue-500 text-white border-blue-500' : `${isDark ? 'bg-white/5 text-gray-400 border-white/10' : 'bg-gray-100 text-gray-600 border-gray-200'}`}`}
                                                >
                                                    Español
                                                </button>
                                            </div>
                                        </div>

                                        {/* Theme Toggle */}
                                        <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-white/5">
                                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">{t('appearance')}</label>
                                            <button 
                                                onClick={toggleTheme}
                                                className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${isDark ? 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10' : 'bg-gray-100 border-gray-200 text-gray-700 hover:bg-gray-200'}`}
                                            >
                                                {isDark ? <i className="fas fa-moon"></i> : <i className="fas fa-sun text-orange-500"></i>}
                                                <span>{isDark ? t('darkMode') : t('lightMode')}</span>
                                            </button>
                                        </div>

                                        {/* Persona Toggle */}
                                        <div className="space-y-3">
                                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">{t('persona')}</label>
                                            <div className="grid grid-cols-2 gap-2">
                                                <button 
                                                    onClick={() => handlePersonaChange('ziki')}
                                                    className={`py-2 px-3 rounded-lg text-sm font-bold border transition-all flex items-center justify-center gap-2 ${persona === 'ziki' ? 'bg-blue-500/20 border-blue-500 text-blue-500' : `${isDark ? 'bg-white/5 border-white/10 text-gray-400' : 'bg-gray-100 border-gray-200 text-gray-600'}`}`}
                                                >
                                                    <i className="fas fa-smile"></i> {t('personaZiki')}
                                                </button>
                                                <button 
                                                    onClick={() => handlePersonaChange('zaka')}
                                                    className={`py-2 px-3 rounded-lg text-sm font-bold border transition-all flex items-center justify-center gap-2 ${persona === 'zaka' ? 'bg-red-500/20 border-red-500 text-red-500' : `${isDark ? 'bg-white/5 border-white/10 text-gray-400' : 'bg-gray-100 border-gray-200 text-gray-600'}`}`}
                                                >
                                                    <i className="fas fa-fire"></i> {t('personaZaka')}
                                                </button>
                                            </div>
                                        </div>
                                    </>
                                )}

                                {settingsMode === 'chat' && !isIncognito && activeChat && (
                                    <>
                                        {/* Model Selection */}
                                        <div className="space-y-3">
                                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">{t('intelligence')}</label>
                                            <div className="grid grid-cols-1 gap-3">
                                                {[ModelType.FLASH, ModelType.PRO, ModelType.THINKING].map(m => (
                                                    <button
                                                        key={m}
                                                        onClick={() => handleModelChange(m)}
                                                        className={`py-3 px-4 rounded-xl text-sm font-medium border transition-all text-left relative overflow-hidden group flex items-center justify-between ${
                                                            (activeChat.modelPreference || globalModel) === m
                                                                ? 'bg-blue-500/10 border-blue-500 text-blue-500'
                                                                : `${isDark ? 'bg-black/20 border-white/5 text-gray-400 hover:bg-white/5' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`
                                                        }`}
                                                    >
                                                        <div className="relative z-10">
                                                            <div className="text-[10px] uppercase tracking-wide opacity-70 mb-0.5">
                                                                {m === ModelType.FLASH ? t('modelFlash') : m === ModelType.PRO ? t('modelPro') : t('modelThinking')}
                                                            </div>
                                                            <div className="font-bold flex items-center gap-2">
                                                                {ModelDisplayNames[m]}
                                                                {m === ModelType.THINKING && <i className="fas fa-brain text-purple-400 text-xs"></i>}
                                                            </div>
                                                        </div>
                                                        {(activeChat.modelPreference || globalModel) === m && (
                                                            <i className="fas fa-check-circle text-blue-500 relative z-10"></i>
                                                        )}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>

                                        {/* Folder Selection */}
                                        <div className="space-y-3">
                                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">{t('moveToFolder')}</label>
                                            <div className="relative">
                                                <select 
                                                    value={activeChat.folderId || 'general'}
                                                    onChange={(e) => updateChatSettings({ folderId: e.target.value })}
                                                    className={`w-full border rounded-xl px-4 py-3 text-sm outline-none focus:border-blue-500 appearance-none cursor-pointer transition ${isDark ? 'bg-black/30 border-white/10 text-white hover:bg-black/40' : 'bg-gray-50 border-gray-200 text-gray-900 hover:bg-gray-100'}`}
                                                >
                                                    {folders.map(f => (
                                                        <option key={f.id} value={f.id} className={isDark ? "bg-[#1e1e24]" : "bg-white"}>
                                                            {getFolderName(f)}
                                                        </option>
                                                    ))}
                                                </select>
                                                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none">
                                                    <i className="fas fa-chevron-down text-xs"></i>
                                                </div>
                                            </div>
                                        </div>

                                        {/* System Prompt */}
                                        <div className="space-y-3">
                                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">{t('systemPrompt')}</label>
                                            <textarea 
                                                value={activeChat.systemInstruction || ''}
                                                onChange={(e) => updateChatSettings({ systemInstruction: e.target.value })}
                                                placeholder={t('systemPromptPlaceholder')}
                                                className={`w-full border rounded-xl px-4 py-3 text-sm h-24 outline-none focus:border-blue-500 resize-none ${isDark ? 'bg-black/30 border-white/10 text-white placeholder-gray-600' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`}
                                            />
                                        </div>
                                    </>
                                )}
                            </div>

                            <div className="mt-8 flex justify-end">
                                <button onClick={() => setSettingsMode(null)} className={`px-6 py-2 rounded-lg text-sm font-semibold transition ${isDark ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                                    {t('done')}
                                </button>
                            </div>

                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};

export default ChatInterface;
