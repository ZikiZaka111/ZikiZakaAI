
import React, { useEffect, useState } from 'react';
import { Emotion, Persona } from '../types';

interface ZikiAvatarProps {
    emotion: Emotion;
    size?: 'xs' | 'sm' | 'md' | 'lg';
    persona?: Persona;
}

const ZikiAvatar: React.FC<ZikiAvatarProps> = ({ emotion, size = 'md', persona = 'ziki' }) => {
    const [blink, setBlink] = useState(false);
    const [lookDirection, setLookDirection] = useState({ x: 0, y: 0 });

    // Blink Logic
    useEffect(() => {
        const blinkLoop = () => {
            setBlink(true);
            setTimeout(() => setBlink(false), 180);
            const nextBlink = Math.random() * 3000 + 2000;
            setTimeout(blinkLoop, nextBlink);
        };
        const timer = setTimeout(blinkLoop, 2000);
        return () => clearTimeout(timer);
    }, []);

    // Thinking: Looking around logic
    useEffect(() => {
        if (emotion === 'thinking') {
            const lookLoop = () => {
                const x = (Math.random() - 0.5) * 8; 
                const y = (Math.random() - 0.5) * 6;
                setLookDirection({ x, y });
                setTimeout(lookLoop, 1500);
            };
            lookLoop();
            return () => setLookDirection({ x: 0, y: 0 });
        } else {
            setLookDirection({ x: 0, y: 0 });
        }
    }, [emotion]);

    // --- Sizing ---
    const sizeClasses = {
        xs: 'w-6 h-6',
        sm: 'w-10 h-10',
        md: 'w-16 h-16',
        lg: 'w-24 h-24' 
    };

    // --- Container Styles (The Orb) ---
    const getContainerStyles = () => {
        const base = "relative rounded-full flex items-center justify-center transition-all duration-500 ease-out flex-shrink-0 select-none";
        
        let visualStyle = "";
        let shapeTransform = "scale(1)";

        // ZAKA (Demon Mode) - 3D Molten Core Look
        if (persona === 'zaka') {
            const zakaBase = "bg-[radial-gradient(circle_at_30%_30%,#fca5a5,#dc2626,#450a0a)] shadow-[inset_-5px_-5px_15px_rgba(0,0,0,0.8),0_0_25px_rgba(220,38,38,0.6)]";
            
            switch (emotion) {
                case 'neutral':
                    visualStyle = zakaBase;
                    break;
                case 'thinking':
                     visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#fdba74,#ea580c,#7c2d12)] shadow-[inset_-5px_-5px_15px_rgba(0,0,0,0.8),0_0_35px_rgba(234,88,12,0.8)] animate-pulse";
                    break;
                case 'happy': // Evil laugh
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#ef4444,#b91c1c,#7f1d1d)] shadow-[inset_-5px_-5px_15px_rgba(0,0,0,0.8),0_0_30px_rgba(220,38,38,0.8)]";
                    shapeTransform = "scale(1.05, 0.95)";
                    break;
                case 'sad': // Bored
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#d1d5db,#4b5563,#1f2937)] shadow-[inset_-5px_-5px_15px_rgba(0,0,0,0.9),0_0_15px_rgba(75,85,99,0.5)]";
                    shapeTransform = "scale(0.95, 1.05)";
                    break;
                case 'angry': // Furious
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#f87171,#991b1b,#450a0a)] shadow-[inset_-5px_-5px_15px_rgba(0,0,0,1),0_0_40px_rgba(255,0,0,0.9)]";
                    shapeTransform = "scale(1.1, 0.9)";
                    break;
                case 'surprised':
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#fbbf24,#d97706,#78350f)] shadow-[inset_-5px_-5px_15px_rgba(0,0,0,0.8),0_0_25px_rgba(245,158,11,0.6)]";
                    shapeTransform = "scale(0.9, 1.1)";
                    break;
            }
        } 
        // ZIKI (Angel Mode) - 3D Glass/Hologram Look
        else {
             const zikiBase = "bg-[radial-gradient(circle_at_30%_30%,#a5b4fc,#6366f1,#312e81)] shadow-[inset_-4px_-4px_10px_rgba(0,0,0,0.3),0_0_20px_rgba(99,102,241,0.5)]";

            switch (emotion) {
                case 'neutral':
                    visualStyle = zikiBase;
                    break;
                case 'thinking':
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#c4b5fd,#8b5cf6,#4c1d95)] shadow-[inset_-4px_-4px_10px_rgba(0,0,0,0.3),0_0_25px_rgba(168,85,247,0.6)] animate-pulse";
                    break;
                case 'happy':
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#6ee7b7,#10b981,#064e3b)] shadow-[inset_-4px_-4px_10px_rgba(0,0,0,0.3),0_0_20px_rgba(16,185,129,0.5)]";
                    shapeTransform = "scale(1.05, 0.95)"; 
                    break;
                case 'sad':
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#93c5fd,#3b82f6,#1e3a8a)] shadow-[inset_-4px_-4px_10px_rgba(0,0,0,0.3),0_0_15px_rgba(59,130,246,0.5)]";
                    shapeTransform = "scale(0.95, 1.05)"; 
                    break;
                case 'angry':
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#fda4af,#f43f5e,#881337)] shadow-[inset_-4px_-4px_10px_rgba(0,0,0,0.3),0_0_25px_rgba(244,63,94,0.6)]";
                    shapeTransform = "scale(1.1, 0.9)"; 
                    break;
                case 'surprised':
                    visualStyle = "bg-[radial-gradient(circle_at_30%_30%,#fcd34d,#f59e0b,#78350f)] shadow-[inset_-4px_-4px_10px_rgba(0,0,0,0.3),0_0_20px_rgba(245,158,11,0.5)]";
                    shapeTransform = "scale(0.9, 1.1)"; 
                    break;
            }
        }

        return { className: `${base} ${visualStyle}`, style: { transform: shapeTransform } };
    };

    // --- Eye Styles ---
    const getEyeStyles = (isLeft: boolean) => {
        const base = {
            position: 'absolute' as const,
            backgroundColor: persona === 'zaka' ? '#fef08a' : 'white', // Pale yellow for Zaka
            boxShadow: persona === 'zaka' 
                ? '0 0 5px rgba(255,200,0,0.8)' // Glow for Zaka
                : 'inset 0 -1px 2px rgba(0,0,0,0.1)', // Soft depth for Ziki
            transformOrigin: 'center',
            transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
        };

        const leftPos = { left: '26%', right: 'auto' };
        const rightPos = { left: 'auto', right: '26%' };
        const pos = isLeft ? leftPos : rightPos;

        if (blink) {
            return {
                ...base, ...pos,
                width: '22%', height: '4%', top: '48%', borderRadius: '2px',
                transform: emotion === 'angry' || persona === 'zaka'
                    ? (isLeft ? 'rotate(12deg)' : 'rotate(-12deg)') 
                    : (emotion === 'sad' ? (isLeft ? 'rotate(-10deg)' : 'rotate(10deg)') : 'scaleX(1.1)')
            };
        }

        // ZAKA Default (Always looks a bit mean/angular)
        if (persona === 'zaka') {
            // Slit eyes usually
            const zakaEye = { ...base, ...pos, borderRadius: '100% 0', width: '22%', height: '22%', top: '38%' };
             
            switch(emotion) {
                case 'neutral':
                     return { ...zakaEye, transform: isLeft ? 'rotate(45deg)' : 'rotate(-45deg) scaleX(-1)' };
                case 'angry':
                    return { ...zakaEye, height: '18%', top:'40%', transform: isLeft ? 'rotate(30deg)' : 'rotate(-30deg) scaleX(-1)' };
                case 'happy': // Evil squint
                    return { ...zakaEye, height: '15%', borderRadius: '50%', transform: isLeft ? 'rotate(10deg) scaleY(0.5)' : 'rotate(-10deg) scaleY(0.5)' };
                case 'surprised':
                    return { ...zakaEye, borderRadius: '50%', width: '18%', height: '26%', transform: 'scale(1.2)' };
                default:
                    return { ...zakaEye, transform: isLeft ? 'rotate(45deg)' : 'rotate(-45deg) scaleX(-1)' };
            }
        }

        // ZIKI Default (Round, Cute)
        switch (emotion) {
            case 'thinking':
                return {
                    ...base, ...pos,
                    width: '24%', height: '24%', top: '28%', borderRadius: '50%',
                    transform: `translate(${lookDirection.x}px, ${lookDirection.y}px)`
                };
            case 'happy':
                return {
                    ...base, ...pos,
                    width: '26%', height: '16%', top: '42%',
                    borderRadius: '50% 50% 40% 40%',
                    transform: isLeft ? 'rotate(-5deg)' : 'rotate(5deg)'
                };
            case 'sad':
                return {
                    ...base, ...pos,
                    width: '24%', height: '26%', top: '38%',
                    borderRadius: '40% 40% 50% 50%',
                    transform: isLeft ? 'rotate(-15deg)' : 'rotate(15deg)'
                };
            case 'angry':
                return {
                    ...base, ...pos,
                    width: '24%', height: '20%', top: '40%',
                    borderRadius: '10% 10% 40% 40%',
                    transform: isLeft ? 'rotate(20deg)' : 'rotate(-20deg)'
                };
            case 'surprised':
                return {
                    ...base, ...pos,
                    width: '22%', height: '35%', top: '30%',
                    borderRadius: '45%',
                    transform: 'scale(1.1)'
                };
            default: // Neutral Ziki
                return {
                    ...base, ...pos,
                    width: '22%', height: '32%', top: '34%',
                    borderRadius: '50%', // Perfect ovals
                };
        }
    };

    // --- Mouth Styles ---
    const getMouthStyles = () => {
        const base = {
            position: 'absolute' as const,
            left: '50%',
            transform: 'translateX(-50%)',
            background: 'rgba(255,255,255,0.8)',
            borderRadius: '10px',
            transition: 'all 0.3s ease',
            opacity: 0
        };

        if (persona === 'zaka') {
             switch (emotion) {
                case 'happy': // Evil grin
                    return { ...base, top: '70%', width: '20%', height: '8%', borderRadius: '0 0 50% 50%', opacity: 1, background: '#450a0a' };
                case 'angry':
                    return { ...base, top: '75%', width: '18%', height: '4%', borderRadius: '5px 5px 0 0', opacity: 1, background: '#450a0a' };
                case 'neutral': // Smirk
                    return { ...base, top: '72%', width: '12%', height: '3%', borderRadius: '2px', opacity: 0.6, background: '#450a0a', transform: 'translateX(-50%) rotate(-5deg)' };
                 default:
                    return { ...base, opacity: 0 };
             }
        }

        switch (emotion) {
            case 'happy':
                return { ...base, top: '68%', width: '18%', height: '10%', borderRadius: '0 0 20px 20px', opacity: 1 };
            case 'surprised':
                return { ...base, top: '75%', width: '12%', height: '12%', borderRadius: '50%', opacity: 1 };
            case 'angry':
                return { ...base, top: '75%', width: '15%', height: '4%', borderRadius: '4px', opacity: 1 };
            case 'sad':
                return { ...base, top: '75%', width: '15%', height: '5%', borderRadius: '10px 10px 0 0', opacity: 0.8 };
            default:
                return base;
        }
    };

    // --- Blush Styles ---
    const getBlushStyles = (isLeft: boolean) => {
        if (persona === 'zaka') return { display: 'none' }; 
        if (emotion !== 'happy' && emotion !== 'surprised') return { display: 'none' };
        
        return {
            position: 'absolute' as const,
            top: '58%',
            left: isLeft ? '18%' : 'auto',
            right: isLeft ? 'auto' : '18%',
            width: '18%',
            height: '10%',
            background: 'rgba(255,150,150, 0.4)',
            filter: 'blur(4px)',
            borderRadius: '50%',
            transition: 'opacity 0.5s'
        };
    };

    const orb = getContainerStyles();

    return (
        <div className={`
            ${sizeClasses[size]} 
            ${orb.className}
            animate-float
        `} style={orb.style}>
            
            {/* 3D Highlight Reflection (Top Left) */}
            <div className="absolute top-[10%] left-[15%] w-[35%] h-[20%] bg-gradient-to-br from-white to-transparent opacity-40 rounded-full blur-[2px] pointer-events-none transform -rotate-12"></div>
            
            {/* Zaka Internal Core Glow */}
            {persona === 'zaka' && (
                <div className="absolute inset-2 rounded-full opacity-60 bg-red-500 blur-md animate-pulse"></div>
            )}

            <div style={getEyeStyles(true)} />
            <div style={getEyeStyles(false)} />
            <div style={getBlushStyles(true)} />
            <div style={getBlushStyles(false)} />
            <div style={getMouthStyles()} />
        </div>
    );
};

export default ZikiAvatar;
