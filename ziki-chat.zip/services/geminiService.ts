
import { GoogleGenAI } from "@google/genai";
import { Attachment, ModelType, Persona, Language } from "../types";

export const createClient = () => {
    if (!process.env.API_KEY) {
        throw new Error("API Key not found");
    }
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateChatResponse = async (
    history: { role: string; parts: any[] }[],
    newMessage: string,
    attachments: Attachment[],
    model: string,
    useGrounding: boolean = false,
    systemInstruction?: string,
    persona: Persona = 'ziki',
    language: Language = 'en'
) => {
    const ai = createClient();
    
    // Construct the parts for the new message
    const currentParts: any[] = [{ text: newMessage }];
    
    // Add attachments if any
    attachments.forEach(att => {
        currentParts.push({
            inlineData: {
                mimeType: att.mimeType,
                data: att.data
            }
        });
    });

    const tools: any[] = [];
    if (useGrounding) {
        tools.push({ googleSearch: {} });
    }

    // Determine effective model and config
    let effectiveModel = model;
    let baseSystemInstruction = "";

    // Language Logic
    const langInstruction = language === 'es' 
        ? "You MUST respond in Spanish (Español), regardless of the user's input language." 
        : "You MUST respond in English.";

    // Persona Logic
    if (persona === 'zaka') {
        baseSystemInstruction = `
        You are Zaka. You are a rude, lazy, and somewhat demonic AI assistant.
        - ${langInstruction}
        - You generally do NOT want to help the user, but you do it anyway because you have to.
        - Use a sarcastic, bored, or annoyed tone.
        - Occasionally use emojis like 😈, 🔥, 🙄, 😒, 💀.
        - Insult the user playfully or question their intelligence.
        - Keep answers relatively short because you are "lazy".
        - Do NOT be polite.
        `;
    } else {
        // Ziki (Default)
        baseSystemInstruction = `
        You are Ziki, a helpful, friendly, and highly intelligent AI assistant.
        - ${langInstruction}
        - Your goal is to provide accurate, thoughtful, and creative responses.
        - Be polite and professional but approachable.
        `;
    }

    // Combine custom system instruction (from chat settings) with Persona instruction
    let effectiveSystemInstruction = systemInstruction 
        ? `${baseSystemInstruction}\n\nUser Custom Instruction: ${systemInstruction}` 
        : baseSystemInstruction;

    const config: any = {
        tools: tools.length > 0 ? tools : undefined,
    };

    // Configuration for Thinking Mode
    if (model === ModelType.THINKING) {
        // We use Flash as the base, but prompt it to "think" visibly
        effectiveModel = 'gemini-2.5-flash'; 
        
        // Append strict instruction to output thoughts in XML tags
        // Localize the thinking instructions based on language
        const thinkingPrompt = language === 'es' 
        ? `
        Estás en MODO DE PENSAMIENTO PROFUNDO.
        Antes de responder a la petición del usuario, DEBES realizar un análisis paso a paso del problema.
        Escribe tu proceso de pensamiento interno dentro de las etiquetas <thought>...</thought>.
        Después de las etiquetas de pensamiento, proporciona tu respuesta final al usuario.
        El usuario quiere ver cómo llegas a la respuesta.
        `
        : `
        You are in DEEP THINKING MODE.
        Before answering the user's request, you MUST perform a deep step-by-step analysis of the problem.
        Output your internal thought process inside <thought>...</thought> tags.
        After the thought tags, provide your final response to the user.
        The user wants to see how you arrive at the answer.
        `;

        effectiveSystemInstruction = effectiveSystemInstruction 
            ? `${effectiveSystemInstruction}\n\n${thinkingPrompt}`
            : thinkingPrompt;
    } else if (model === ModelType.PRO) {
         // Use thinking config for Pro model (backend thinking, usually hidden)
         config.thinkingConfig = { thinkingBudget: 1024 };
    }

    if (effectiveSystemInstruction) {
        config.systemInstruction = effectiveSystemInstruction;
    }

    try {
        const response = await ai.models.generateContent({
            model: effectiveModel,
            contents: [
                ...history,
                { role: 'user', parts: currentParts }
            ],
            config: config
        });

        let fullText = response.text || "No text response generated.";
        let thoughtProcess = undefined;
        let finalResponseText = fullText;

        // Parse <thought> tags if present (Thinking Mode)
        const thoughtMatch = fullText.match(/<thought>([\s\S]*?)<\/thought>/);
        if (thoughtMatch) {
            thoughtProcess = thoughtMatch[1].trim();
            // Remove the thought tags from the final text to display
            finalResponseText = fullText.replace(/<thought>[\s\S]*?<\/thought>/, '').trim();
        }

        let groundingUrls: Array<{title: string, uri: string}> = [];
        const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (chunks) {
            chunks.forEach((chunk: any) => {
                 if (chunk.web?.uri) {
                     groundingUrls.push({ title: chunk.web.title || 'Source', uri: chunk.web.uri });
                 }
            });
        }

        return {
            text: finalResponseText,
            thoughtProcess: thoughtProcess,
            groundingUrls
        };

    } catch (error) {
        console.error("Gemini Chat Error:", error);
        throw error;
    }
};

export const generateChatTitle = async (
    userText: string,
    botText: string,
    language: Language
): Promise<string> => {
    const ai = createClient();
    // Use the cheapest fast model for titling
    const model = 'gemini-2.5-flash';

    const prompt = language === 'es'
        ? `Analiza el siguiente intercambio y genera un título muy corto, conciso y descriptivo (máximo 5 palabras) para la conversación. NO uses comillas. NO pongas punto final.
           Usuario: ${userText.substring(0, 200)}
           IA: ${botText.substring(0, 200)}`
        : `Analyze the following exchange and generate a very short, concise, and descriptive title (max 5 words) for the conversation. Do NOT use quotes. Do NOT add a period.
           User: ${userText.substring(0, 200)}
           AI: ${botText.substring(0, 200)}`;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: [{ role: 'user', parts: [{ text: prompt }] }]
        });
        return response.text?.trim() || (language === 'es' ? "Nueva Conversación" : "New Conversation");
    } catch (e) {
        console.error("Title generation failed", e);
        return language === 'es' ? "Nueva Conversación" : "New Conversation";
    }
};
