
export enum ModelType {
  FLASH = 'gemini-2.5-flash', // Standard
  PRO = 'gemini-3-pro-preview', // Reasoning/Analysis
  THINKING = 'gemini-2.5-flash-thinking', // Custom Thinking Mode
  LIVE_AUDIO = 'gemini-2.5-flash-native-audio-preview-09-2025', // Live
}

export const ModelDisplayNames: Record<ModelType, string> = {
  [ModelType.FLASH]: 'Ziki 1.5',
  [ModelType.PRO]: 'Ziki 2.0',
  [ModelType.THINKING]: 'Ziki Thoughts',
  [ModelType.LIVE_AUDIO]: 'Ziki Live'
};

export type Emotion = 'neutral' | 'happy' | 'angry' | 'sad' | 'surprised' | 'thinking';

export type Theme = 'dark' | 'light';
export type Language = 'en' | 'es';
export type Persona = 'ziki' | 'zaka';

export interface Attachment {
  mimeType: string;
  data: string; // Base64
  name?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text?: string;
  thoughtProcess?: string; // Content extracted from <thought> tags
  attachments?: Attachment[];
  timestamp: number;
  groundingUrls?: Array<{title: string; uri: string}>;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  lastUpdated: number;
  folderId?: string; // Optional, defaults to 'general'
  systemInstruction?: string; // Custom prompt for this chat
  modelPreference?: ModelType;
}

export interface Folder {
  id: string;
  name: string;
  isSystem?: boolean; // If true, cannot be deleted (e.g. General)
  isOpen?: boolean; // UI state for accordion
}